from ghPublish.cli import cli
_VERSION = '1.0.1'
