Please visit https://github.com/MiteshNinja/ghPublish for more details.


