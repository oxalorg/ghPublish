from ghPublish.cli import cli
_VERSION = '0.8.2'
